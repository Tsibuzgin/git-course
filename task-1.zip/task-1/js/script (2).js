//Вопрос к пользователю
let userName = prompt("What is your name?", "");
//Вывод всплывающего окна
alert('Hello, ' + userName + '! How are you?');
 